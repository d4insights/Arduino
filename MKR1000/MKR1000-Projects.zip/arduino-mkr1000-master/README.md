# Getting to Know Arduino's MKR1000

Tutorial: https://www.pubnub.com/blog/2016-08-10-getting-to-know-arduinos-mkr1000/

Jump into Arduino's MKR1000 and explore its WiFi capabilities, find out how to create an access point,publish data, and use flash storage, plus so much more.
